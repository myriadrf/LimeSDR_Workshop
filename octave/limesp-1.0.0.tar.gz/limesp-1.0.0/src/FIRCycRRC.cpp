/*
 Copyright 2017 Lime Microsystems Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
// requires liboctave-dev
// to compile...
// mkoctfile FIRCycRRC.cpp -Wall -O3
// to test...
// octave
// x=[1,-1,1,1,-1,-1]; % BPSK before oversampling, RRC filtering and autoscale
// hrrc=FIRMakeCoefsRRCOdd(0.22,5,4);
// y=FIRCycRRC(x,0.22,5,4,1);
// z=AutoScalePk(FIRTimeCP(UpSample(x,4),hrrc)) % equivalent function verified against
// plot(real(y),"bo-",real(z),"rx-");
// y=FIRCycRRC(i*x,0.22,5,4,1);
// z=AutoScalePk(FIRTimeCP(UpSample(i*x,4),hrrc)) % equivalent function verified against
// plot(imag(y),"bo-",imag(z),"rx-");
// y=FIRCycRRC(y,0.22,5,4,0); % no upsample
// this is circular version of impulse function response, so last point connects seemlessly with first point.
// this is useful if we have a single frame signal 
// and we can use the end of the frame as part of the FIR history for the first part of the signal
#include <octave/oct.h>
#include <oct-cmplx.h>
#include <time.h>       // clock_t, clock, CLOCKS_PER_SEC

#define _PI 3.14159265359

int rrc( double *hrrc, double beta, int symb, int osr );

int rrc( double *hrrc, double beta, int symb, int osr )
{
	double tothrrc=0.0;
	double ts=1.0;
	double t=0.0;
	double val=0.0;
	int len=2*osr*symb+1;
	for( int ci=0; ci<len; ci++ )
	{
		t=(-osr*symb+ci)*1.0/osr;
		if (t==0.0)
			val=(1-beta+4*beta/_PI)/sqrt(ts);
		else
			if (abs(t)==(ts/4/beta))
				val=beta*((1+2/_PI)*sin(_PI/4/beta)+(1-2/_PI)*cos(_PI/4/beta))/sqrt(2*ts);
			else
			{
				val=(sin(_PI*t/ts*(1-beta))+4*beta*t*cos(_PI*t/ts*(1+beta))/ts);
				val/=sqrt(ts)*(_PI*t*(1-(4*beta*t/ts)*(4*beta*t/ts))/ts);
			}
		hrrc[ci]=val;
		tothrrc+=hrrc[ci]*hrrc[ci];
	}
	tothrrc=sqrt(tothrrc); // use RMS as coefficients are signed numbers
	for( int ci=0; ci<len; ci++ )
		hrrc[ci]/=tothrrc; // normalise, so integral of impulse response is unity
	return(len);
}

DEFUN_DLD (FIRCycRRC, args, , "FIRCycRRC( iqData, alpha, symbols, osr, doUpSample )")
{
clock_t mytref = clock();
	int nargin = args.length ();
	if (nargin != 5)
		print_usage ();
	else // https://www.gnu.org/software/octave/doc/v4.0.1/Matrices-and-Arrays-in-Oct_002dFiles.html
	{ // inputs
		ComplexRowVector		iqdatax=args(0).complex_row_vector_value();
		dim_vector			iqdataSize=iqdatax.dims();
		double				alpha=args(1).double_value();
		int				symb=args(2).int_value();
		int				osr=args(3).int_value();
		int				doUp=args(4).int_value();
		// private
		long				ptsi=iqdataSize(1);
		long				ptso=ptsi;
		if( doUp>0 )
			ptso=ptsi*osr;
		double *hrrc=(double*)malloc( sizeof(double)*(2*osr*symb+1) );
		int hpts=rrc( hrrc, alpha, symb, osr );
		Complex	*dataz=(Complex*)malloc( sizeof(Complex)*ptso ); // faster to use C native dynamic storage
		Complex *datay=(Complex*)malloc( sizeof(Complex)*ptso );
		Complex	myZero(0.0,0.0); // typedef Complex std::complex<double> in /usr/include/octave-3.6.2/oct-cmplx.h
		// outputs
		ComplexRowVector		iqdatay( ptso, 0 ); // assuming row vector input! Should really check!!!
		for( long cj=0; cj<ptso; cj++ ) // insert zeros between points
		{
			datay[cj]=myZero;
			dataz[cj]=myZero;
		}
		if( doUp>0 )  // UpSample() function
			for( long cj=0; cj<ptsi; cj++ )
				dataz[osr*cj]=iqdatax(cj);
		else
			for( long cj=0; cj<ptsi; cj++ )
				dataz[cj]=iqdatax(cj);
// printf ("FIRCycRRC: A %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
//		printf("ptsi=%li ptso=%li hpts=%i\n", ptsi, ptso, hpts );
		long	tmpl=0;
		for(long ci=0; ci<ptso; ci++ ) // FIRTimeCP() function
			for( short cj=0; cj<hpts; cj++ )
			{
				tmpl=ci-cj;
				if( tmpl<0 )
					tmpl=(tmpl % ptso)+ptso; // tmpl=tmpl+pts fails if pts<hrrc
				datay[ci] += dataz[tmpl]*hrrc[cj];
			}
// printf ("FIRCycRRC: B %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		free(hrrc);
		double maxval=0.0;
		double temp=0.0;
		for(long ci=0; ci<ptso; ci++ ) // AutoScalePk() function
		{
			temp = abs(datay[ci]);
			if( temp>maxval )
				maxval=temp;
		}
		maxval=1.0/maxval;
		for(long ci=0; ci<ptso; ci++ ) // scale waveform by 1/max value
			iqdatay(ci) = datay[ci]*maxval;
		free(datay);
		free(dataz);
printf ("FIRCycRRC: %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		return octave_value ( iqdatay );
	}
	return octave_value_list ();
}

