/*
 Copyright 2017 Lime Microsystems Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
// requires liboctave-dev
// to compile...
// mkoctfile FIRCycGaussInt.cpp -Wall -O3 -v
// to test...
// octave
// x=[1,-1,1,1,-1,-1]; % BPSK before oversampling, RRC filtering and autoscale
// x=2*randint(1,64)-1;
// y=FIRCycGauss(x,0.3,2,8,1);
// d=diff(unwrap(arg(y)),1); % FM demodulation of GMSK
// this is circular version of impulse function response, so last point connects seemlessly with first point.
// this is useful if we have a single frame signal 
// and we can use the end of the frame as part of the FIR history for the first part of the signal
#include <octave/oct.h>
#include <oct-cmplx.h>
#include <time.h>       // clock_t, clock, CLOCKS_PER_SEC

#define _PI 3.14159265359

// ETSI TS 145 004 v4.2.0 (2001-11) page 6-7
// h(t)=exp(-t^2//2/T/T/d/d)/sqrt(2pi)/d/T
// d=sqrt(ln(2))/2/pi/Bt => 0.13251 = 1/7.5466
// BT=0.3 for GSM and 0.5 for bluetooth
int gauss( double *hgs, double bt, int symb, int osr );

int gauss( double *hgs, double bt, int symb, int osr )
{
	double tothgs=0.0;
	double t=0.0;
	int len=2*osr*symb+1;
	double a=2*_PI*bt/sqrt(log(2));
	for( int ci=0; ci<len; ci++ )
	{
		t=(-osr*symb+ci)*1.0/osr;
		hgs[ci]=a*exp(-t*t*a*a/2)/sqrt(2*_PI);
		tothgs+=hgs[ci];
	}
	tothgs=2*tothgs/_PI; // area under gauss pulese should be pi/2
	for( int ci=0; ci<len; ci++ )
		hgs[ci]/=tothgs; // normalise, so integral of impulse response is unity
	return(len);
}

DEFUN_DLD (FIRCycGaussInt, args, , "FIRCycGaussInt( realData, BT, symbols, osr, doUpSample )")
{
clock_t mytref = clock();
	int nargin = args.length ();
	if (nargin != 5)
		print_usage ();
	else
	{ // https://www.gnu.org/software/octave/doc/v4.0.1/Matrices-and-Arrays-in-Oct_002dFiles.html
		// inputs
		RowVector			iqdatax=args(0).row_vector_value();
		dim_vector			iqdataSize=iqdatax.dims();
		double				bt=args(1).double_value();
		int				symb=args(2).int_value();
		int				osr=args(3).int_value();
		int				doUp=args(4).int_value();
		// private
		long				ptsi=iqdataSize(1);
		long				ptso=ptsi;
		if( doUp>0 )
			ptso=ptsi*osr;
		double *hgs=(double*)malloc( sizeof(double)*(2*osr*symb+1) );
		short hpts=gauss( hgs, bt, symb, osr );
		double	*dataz=(double*)malloc( sizeof(double)*ptso ); // faster to use C native dynamic storage
		double	*datay=(double*)malloc( sizeof(double)*ptso );
		// outputs
		ComplexRowVector		iqdatay( ptso, 0 ); // assuming row vector input! Should really check!!!
		for( long cj=0; cj<ptso; cj++ ) // insert zeros between points
		{
			datay[cj]=0.0;
			dataz[cj]=0.0;
		}
		if( doUp>0 )  // UpSample() function
			for( long cj=0; cj<ptsi; cj++ )
				dataz[osr*cj]=iqdatax(cj);
		else
			for( long cj=0; cj<ptsi; cj++ )
				dataz[cj]=iqdatax(cj);
//printf ("FIRCycGaussInt: A %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
//		printf("ptsi=%li ptso=%li hpts=%i\n", ptsi, ptso, hpts );
		long	tmpl=0;
		for(long ci=0; ci<ptso; ci++ ) // FIRTimeCP() function
			for( short cj=0; cj<hpts; cj++ )
			{
				tmpl=ci-cj;
				if( tmpl<0 )
					tmpl=(tmpl % ptso)+ptso; // tmpl=tmpl+pts fails if pts<hrrc
				datay[ci] += dataz[tmpl]*hgs[cj];
			}
//printf ("FIRCycGaussInt: B %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		free(hgs);
		double acc=0.0;
		Complex pharg;
		for(long ci=0; ci<ptso; ci++ ) // GSMIntegrateSeq() function
		{
			acc+=datay[ci];;
			pharg=Complex(0,acc); // phase-->complex IQ point with unity amplitude - GSMWave() function
			iqdatay(ci)=exp(pharg);
		}
		free(datay);
		free(dataz);
printf ("FIRCycGaussInt: %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		return octave_value ( iqdatay );
	}
	return octave_value_list ();
}

