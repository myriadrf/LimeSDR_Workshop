/*
 Copyright 2017 Lime Microsystems Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
// requires liboctave-dev
// to compile...
// mkoctfile FIRCycRC.cpp -Wall -O3
// to test...
// octave
// x=[1,-1,1,1,-1,-1]; % BPSK before oversampling, RRC filtering and autoscale
// hrc=FIRMakeCoefsRCOdd(0.22,5,4);
// y=FIRCycRC(x,0.22,5,4,1);
// z=AutoScalePk(FIRTimeCP(UpSample(x,4),hrc)) % equivalent function verified against
// plot(real(y),"bo-",real(z),"rx-");
// y=FIRCycRC(i*x,0.22,5,4,1);
// z=AutoScalePk(FIRTimeCP(UpSample(i*x,4),hrc)) % equivalent function verified against
// plot(imag(y),"bo-",imag(z),"rx-");
// y=FIRCycRC(y,0.22,5,4,0); % no upsample
// this is circular version of impulse function response, so last point connects seemlessly with first point.
// this is useful if we have a single frame signal 
// and we can use the end of the frame as part of the FIR history for the first part of the signal
#include <octave/oct.h>
#include <oct-cmplx.h>
#include <time.h>       // clock_t, clock, CLOCKS_PER_SEC

#define _PI 3.14159265359

int rc( double *hrc, double beta, int symb, int osr );

int rc( double *hrc, double beta, int symb, int osr )
{
	double tothrc=0.0;
	double ts=1.0;
	double t=0.0;
	double val=0.0;
	int len=2*osr*symb+1;
	for( int ci=0; ci<len; ci++ )
	{
		t=(-osr*symb+ci)*1.0/osr;
		if(t==0)
			val=1;
		else
		{
			val=sin(_PI*t/ts)*cos(_PI*t*beta/ts);
			val/=(_PI*t/ts)*(1-(2*beta*t/ts)*(2*beta*t/ts));
		}
		hrc[ci]=val;
		tothrc+=hrc[ci]*hrc[ci];
	}
	tothrc=sqrt(tothrc); // use RMS as coefficients are signed numbers
	for( int ci=0; ci<len; ci++ )
		hrc[ci]/=tothrc; // normalise, so integral of impulse response is unity
	return(len);
}

DEFUN_DLD (FIRCycRC, args, , "FIRCycRC( iqData, alpha, symbols, osr, doUpSample )")
{
clock_t mytref = clock();
	int nargin = args.length ();
	if (nargin != 5)
		print_usage ();
	else // https://www.gnu.org/software/octave/doc/v4.0.1/Matrices-and-Arrays-in-Oct_002dFiles.html
	{ // inputs
		ComplexRowVector		iqdatax=args(0).complex_row_vector_value();
		dim_vector			iqdataSize=iqdatax.dims();
		double				alpha=args(1).double_value();
		int				symb=args(2).int_value();
		int				osr=args(3).int_value();
		int				doUp=args(4).int_value();
		// private
		long				ptsi=iqdataSize(1);
		long				ptso=ptsi;
		if( doUp>0 )
			ptso=ptsi*osr;
		double *hrc=(double*)malloc( sizeof(double)*(2*osr*symb+1) );
		int hpts=rc( hrc, alpha, symb, osr );
		Complex	*dataz=(Complex*)malloc( sizeof(Complex)*ptso ); // faster to use C native dynamic storage
		Complex *datay=(Complex*)malloc( sizeof(Complex)*ptso );
		Complex	myZero(0.0,0.0); // typedef Complex std::complex<double> in /usr/include/octave-3.6.2/oct-cmplx.h
		// outputs
		ComplexRowVector		iqdatay( ptso, 0 ); // assuming row vector input! Should really check!!!
		for( long cj=0; cj<ptso; cj++ ) // insert zeros between points
		{
			datay[cj]=myZero;
			dataz[cj]=myZero;
		}
		if( doUp>0 )  // UpSample() function
			for( long cj=0; cj<ptsi; cj++ )
				dataz[osr*cj]=iqdatax(cj);
		else
			for( long cj=0; cj<ptsi; cj++ )
				dataz[cj]=iqdatax(cj);
// printf ("FIRCycRC: A %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
//		printf("ptsi=%li ptso=%li hpts=%i\n", ptsi, ptso, hpts );
		long	tmpl=0;
		for(long ci=0; ci<ptso; ci++ )
			for( int cj=0; cj<hpts; cj++ )  // FIRTimeCP() function
			{
				tmpl=ci-cj;
				if( tmpl<0 )
					tmpl=(tmpl % ptso)+ptso; // tmpl=tmpl+pts fails if pts<hrrc
				datay[ci] += dataz[tmpl]*hrc[cj];
			}
// printf ("FIRCycRC: B %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		free(hrc);
		double maxval=0.0;
		double temp=0.0;
		for(long ci=0; ci<ptso; ci++ ) // AutoScalePk() function
		{
			temp = abs(datay[ci]);
			if( temp>maxval )
				maxval=temp;
		}
		maxval=1.0/maxval;
		for(long ci=0; ci<ptso; ci++ ) // scale waveform by 1/max value
			iqdatay(ci) = datay[ci]*maxval;
		free(datay);
		free(dataz);
printf ("FIRCycRC: %f seconds\n",((float)(clock()-mytref))/CLOCKS_PER_SEC);
		return octave_value ( iqdatay );
	}
	return octave_value_list ();
}

