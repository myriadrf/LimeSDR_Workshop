function hrrc=FIRMakeCoefsRC( tt, beta ) % beta is the same as alpha!
	ts=1.0;
	hrrc=1:length(tt);
	for ci=1:length(tt)
		t=tt(ci);
		if (t==0)
			val=1;
		else
			val=sin(pi*t/ts)*cos(pi*t*beta/ts);
			val/=(pi*t/ts)*(1-(2*beta*t/ts)^2);
		end
		hrrc(ci)=val;
		%printf( "%g %g\n", t, val );
	end
	tothrrc=sum(hrrc);
	hrrc/=tothrrc;
end

