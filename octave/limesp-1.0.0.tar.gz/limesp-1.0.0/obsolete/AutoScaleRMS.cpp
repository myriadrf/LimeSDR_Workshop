/*
 Copyright 2016 Lime Microsystems Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
// requires liboctave-dev
// to compile...
// mkoctfile AutoScaleRMS.cpp
// to test...
// octave
// x=[0,0.25,-0.5,1,2*i];
// y=AutoScaleRMS(x);
// y= 0.00000+0.00000i, 0.26650+0.00000i, -0.53300+0.00000i, 1.06600+0.00000i, 0.00000+2.13201i
// scales waveform so rms is 1.0
#include <octave/oct.h>
#include <oct-cmplx.h>

DEFUN_DLD (AutoScaleRMS, args, , "AutoScaleRMS( iqData )")
{
	short nargin = args.length ();
	if (nargin != 1)
		print_usage ();
	else
	{
		// inputs
		ComplexRowVector	iqdatax=args(0).complex_row_vector_value();
		dim_vector			iqdataSize=iqdatax.dims();
		// outputs
		ComplexRowVector			iqdatay( iqdataSize(1), 0 );	// assuming we are getting row vector input! Should really check!!!	
		long int pts=iqdataSize(1);
		Complex	avg=0.0;
		Complex	msq=0.0;
		double	irmsq=0.0;
		double	temp=0.0;
		// find average value
		for(long int i=0; i<pts; i++ )
		{
			// note typedef Complex is defined as std::complex<double> defined in /usr/include/octave-3.6.2/oct-cmplx.h
			octave_value xtemp=iqdatax(i);
			avg+=xtemp.complex_value();
		}
		avg/=pts;
		// calculate standard deviation
		for(long int i=0; i<pts; i++ )
		{
			octave_value xtemp=iqdatax(i);
			// note use of conjugate for complex numbers to ensure product is wholly real
			msq+=(xtemp.complex_value()-avg)*conj(xtemp.complex_value()-avg);
		}
		msq/=pts; // variance
		irmsq=1.0/sqrt(abs(msq));
		// scale waveform by 1/msq value
		for(long int i=0; i<pts; i++ )
		{
			octave_value xtemp=iqdatax(i);
			Complex xvalue=xtemp.complex_value();				
			iqdatay(i) = xvalue*irmsq;
		}
		return octave_value ( iqdatay );
	}
	return octave_value_list ();
}

