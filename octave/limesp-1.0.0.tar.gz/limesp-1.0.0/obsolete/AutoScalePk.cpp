/*
 Copyright 2016 Lime Microsystems Ltd.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
*/
// requires liboctave-dev
// to compile...
// mkoctfile AutoScalePk.cpp
// to test...
// octave
// x=[0,0.25,-0.5,1,2*i];
// y=AutoScale(x);
// scales waveform so maximum peak is 1.0
#include <octave/oct.h>
#include <oct-cmplx.h>

DEFUN_DLD (AutoScalePk, args, , "AutoScalePk( iqData )")
{
	short nargin = args.length ();
	if (nargin != 1)
		print_usage ();
	else
	{
		// inputs
		ComplexRowVector	iqdatax=args(0).complex_row_vector_value();
		dim_vector			iqdataSize=iqdatax.dims();
		// outputs
		ComplexRowVector			iqdatay( iqdataSize(1), 0 );	// assuming we are getting row vector input! Should really check!!!	
		long int pts=iqdataSize(1);
		double	max=0.0;
		double	temp=0.0;
		// find max value
		for(long int i=0; i<pts; i++ )
		{
			// note typedef Complex is defined as std::complex<double> defined in /usr/include/octave-3.6.2/oct-cmplx.h
			octave_value xtemp=iqdatax(i);
			Complex xvalue=xtemp.complex_value();
			temp = abs(xvalue);
			if( temp>max )
				max=temp;
		}
		// scale waveform by 1/max value
		max=1.0/max;
		for(long int i=0; i<pts; i++ )
		{
			octave_value xtemp=iqdatax(i);
			Complex xvalue=xtemp.complex_value();				
			iqdatay(i) = xvalue*max;
		}
		return octave_value ( iqdatay );
	}
	return octave_value_list ();
}

