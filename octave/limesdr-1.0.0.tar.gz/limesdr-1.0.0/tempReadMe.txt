LINUX INSTALL
=============

Currently supporting Octave 4.0.0 on Ubuntu.  Other versions may also work.

cd ~
mkdir octave

Copy limesdr-1.0.0.tar.gz into the ~/octave folder

Start Octave

pkg install ~/octave/limesdr-1.0.0.tar.gz

To uninstall

pkg uninstall limesdr



WINDOWS INSTALL
===============

Currently supporting Octave 4.0.3 only.  Octave 4.2.1 has a bug which affects use.

Plan is Pothosware's Pothos is being used to distribute LimeSuite.dll 

https://github.com/pothosware/pothos/wiki/Downloads

This will be installed in C:\Program Files\PothosSDR\bin

This path has to be added to the environmental variable PATH either by Pothos installer or manually 
e.g. System Control Panel -> Advance System Settings -> Environmental Variables -> Edit PATH and add ;C:\Program Files\PothosSDR\bin

Then in system console

cd %USERPROFILE%

mkdir octave

Copy limesdr-1.0.0.tar.gz into the %USERPROFILE%/octave folder

Start Octave

pkg install ~/octave/limesdr-1.0.0.tar.gz

To uninstall

pkg uninstall limesdr



MAC OS X INSTALL
================

Think there is a bug in Homebrew edition of Octave installer.  Building packages fails.

